#' Construct SQL expressions for a design matrix
#'
#' Expands formula terms into SQL SELECT expressions, handling factor one-hot
#' encoding and interaction terms. Only the right-hand side of the formula is
#' processed; the response variable (LHS) is ignored.
#'
#' @param formula A formula (or Formula) object. Only RHS terms are expanded;
#'   the LHS (response variable) is ignored.
#' @param conn Database connection
#' @param table Table name or FROM clause
#' @param expand Character: `"all"` expands factors and interactions, 
#'   `"interactions"` only expands interaction terms (factors in main effects 
#'   kept as-is for grouping)
#' @param sep Character separator for interaction term names. Default is
#'   `"_x_"`. Use `":"` for standard R naming convention.
#' @param fe_vars Character vector of fixed effect variable names. These are
#'   treated as "in the model" for determining whether to drop reference levels
#'   in interactions.
#' @param intercept Logical. Whether the model has an intercept. As in
#'   [stats::model.matrix()], without an intercept the first factor main effect
#'   keeps all of its levels (no reference level is dropped).
#' @param factor_refs Optional named reference levels for categorical regressors.
#' @return List with:
#'   - `select_exprs`: character vector of SQL expressions
#'   - `col_names`: corresponding column names
#'   - `aliases`: SQL-safe versions of `col_names` (identical unless, e.g.,
#'     factor levels contain spaces or other special characters)
#'   - `level_aliases`: data frame mapping each factor dummy `alias` to its
#'     `var` and `level`
#'   - `factor_levels`: list of factor levels by variable (for reference)
#' @importFrom stats terms
#' @export
#' @examples
#' library(DBI)
#' library(duckdb)
#' con = dbConnect(duckdb())
#' duckdb_register(con, "test", data.frame(x1 = 1:3, x2 = c("a", "b", "c")))
#' sql_model_matrix(~ x1 + x2, con, "test")
#' sql_model_matrix(~ x1:x2, con, "test")
#' sql_model_matrix(~ x1:x2, con, "test", sep = ":")
#' dbDisconnect(con)
sql_model_matrix = function(
  formula,
  conn,
  table,
  expand = c("all", "interactions"),
  sep = "_x_",
  fe_vars = character(),
  intercept = TRUE,
  factor_refs = NULL
) {
  expand = match.arg(expand)
  
  # Extract terms from formula (handles Formula objects too)
  if (inherits(formula, "Formula")) {
    formula = formula(formula, lhs = 0, rhs = 1)
  }
  tt = terms(formula)
  term_labels = attr(tt, "term.labels")
  
  if (!length(term_labels)) {
    return(list(
      select_exprs = character(), col_names = character(), aliases = character(),
      factor_levels = list(), level_aliases = data.frame(alias = character(), var = character(), level = character())
    ))
  }
  
  # Get column types and factor levels from database
  col_info = get_column_info(conn, table, term_labels, factor_refs)

  # SQL-safe aliases for factor dummies, one per (variable, level), computed
  # once so that every term uses the same alias. They avoid the model's
  # variable names and each other, and follow the backend's case rules.
  fold_case = folds_identifier_case(conn)
  taken = names(col_info[["types"]])
  level_aliases = list()
  for (v in names(col_info[["levels"]])) {
    lvls = c(as.character(col_info[["levels"]][[v]]), "_constant")
    a = safe_identifiers(paste0(v, lvls), taken = taken, fold_case = fold_case)
    taken = c(taken, a)
    level_aliases[[v]] = data.frame(alias = a, var = v, level = lvls)
  }
  level_aliases = do.call(rbind, c(list(data.frame(alias = character(), var = character(), level = character())), level_aliases))
  col_info[["level_aliases"]] = level_aliases
  components = unique(unlist(lapply(term_labels, split_interaction_term)))
  powers = components[vapply(components, function(t) !is.null(parse_power_term(t)), logical(1))]
  col_info[["power_aliases"]] = if (length(powers)) setNames(safe_identifiers(
    paste0("dbreg_power_", seq_along(powers), "__"), taken = taken, fold_case = fold_case), powers) else character()

  result = list(select_exprs = character(), col_names = character(), aliases = character())
  
  # Without an intercept, the first factor main effect keeps all its levels
  full_factor = if (!intercept) {
    is_factor_main = vapply(term_labels, function(t) {
      !grepl(":", t, fixed = TRUE) && identical(col_info[["types"]][[t]], "factor")
    }, logical(1))
    term_labels[is_factor_main][1]
  }
  for (term in term_labels) {
    expanded = expand_term(
      term, col_info, expand, sep,
      all_terms = unique(c(term_labels, fe_vars)),
      fe_vars = fe_vars,
      keep_all_levels = identical(term, full_factor)
    )
    result[["select_exprs"]] = c(result[["select_exprs"]], expanded[["sql"]])
    result[["col_names"]] = c(result[["col_names"]], expanded[["name"]])
    result[["aliases"]] = c(result[["aliases"]], expanded[["alias"]])
  }
  
  result[["factor_levels"]] = col_info[["levels"]]
  result[["level_aliases"]] = level_aliases
  result
}

#' Get column types and factor levels from database
#' @keywords internal
get_column_info = function(conn, table, term_labels, factor_refs = NULL) {
  # Extract unique variable names from all terms
  vars = unique(unlist(lapply(term_labels, function(t) all.vars(str2lang(t)))))
  
  # Build FROM clause
  from_sql = if (grepl("^FROM", table, ignore.case = TRUE)) table else paste("FROM", table)
  
  # Query to get types and sample values
  # Fetch zero rows to get the schema, then separate queries for factor levels
  # (sql_limit() handles dialects without LIMIT, e.g. SQL Server's TOP)
  backend = detect_backend(conn)[["name"]]
  schema_query = sql_limit(glue("SELECT {paste(vars, collapse = ', ')} {from_sql}"), 0, backend)
  schema = dbGetQuery(conn, schema_query)
  
  types = list()
  levels = list()
  
  for (v in vars) {
    col_class = class(schema[[v]])[1]
    # Treat character, factor, logical as categorical
    if (col_class %in% c("character", "factor", "logical") || v %in% names(factor_refs)) {
      types[[v]] = "factor"
      # All distinct levels (a sample could miss rare levels)
      lvl_query = glue("SELECT DISTINCT {v} FROM (SELECT {v} {from_sql}) lvl WHERE {v} IS NOT NULL ORDER BY {v}")
      levels[[v]] = dbGetQuery(conn, lvl_query)[[1]]
      if (v %in% names(factor_refs)) {
        ref = match(as.character(factor_refs[[v]]), as.character(levels[[v]]))
        if (is.na(ref)) stop("Reference level was not found in regressor `", v, "`.", call. = FALSE)
        levels[[v]] = levels[[v]][c(ref, setdiff(seq_along(levels[[v]]), ref))]
      }
    } else {
      types[[v]] = "numeric"
    }
  }
  
  list(types = types, levels = levels)
}

#' Expand a single term into SQL expressions
#'
#' Expansions are lists of parallel character vectors: `sql` (expressions),
#' `name` (column names) and `alias` (SQL-safe column names).
#' @keywords internal
expand_term = function(term, col_info, expand, sep = "_x_", all_terms = character(), fe_vars = character(), keep_all_levels = FALSE) {
  vars = split_interaction_term(term)
  is_interaction = length(vars) > 1
  
  if (!is_interaction && expand == "interactions" && is.null(parse_power_term(term))) {
    # Main effect, only expanding interactions: return as-is
    return(list(sql = term, name = term, alias = term))
  }
  
  # Expand each variable
  expansions = lapply(vars, function(v) {
    drop_ref = !keep_all_levels
    if (is_interaction && identical(col_info[["types"]][[v]], "factor")) {
      other_term = paste(sort(setdiff(vars, v)), collapse = ":")
      drop_ref = v %in% fe_vars || other_term %in% all_terms
    }
    expand_variable(v, col_info, expand, is_interaction, drop_ref)
  })
  
  # Cross product for interactions
  Reduce(function(a, b) cross_product(a, b, sep), expansions, right = TRUE)
}

#' Expand a single variable into SQL expression(s)
#' @keywords internal
expand_variable = function(var, col_info, expand, in_interaction, drop_ref = TRUE) {
  power = parse_power_term(var)
  if (!is.null(power)) {
    return(list(sql = power[["sql"]], name = var, alias = unname(col_info[["power_aliases"]][var])))
  }
  is_factor = identical(col_info[["types"]][[var]], "factor")
  
  # Only expand factors if: expand="all", OR variable is part of interaction
  if (!(is_factor && (expand == "all" || in_interaction))) {
    # Numeric or unexpanded factor: pass through
    return(list(sql = var, name = var, alias = var))
  }
  lvls = col_info[["levels"]][[var]]
  la = col_info[["level_aliases"]]
  la = la[la[["var"]] == var, , drop = FALSE]
  if (length(lvls) < 2) {
    return(list(sql = "1", name = paste0(var, "_constant"), alias = la[["alias"]][la[["level"]] == "_constant"]))
  }
  # Drop first level (reference) only if appropriate
  if (drop_ref) {
    lvls = lvls[-1]
  }
  list(
    # Escape single quotes in level names
    sql = paste0("CASE WHEN ", var, " = '", gsub("'", "''", lvls, fixed = TRUE), "' THEN 1.0 ELSE 0.0 END"),
    name = paste0(var, lvls),
    alias = la[["alias"]][match(lvls, la[["level"]])]
  )
}

#' Cartesian product of two term expansions
#'
#' Columns of `a` vary slowest (as in a nested loop over `a`, then `b`).
#' @keywords internal
cross_product = function(a, b, sep = "_x_") {
  i = rep(seq_along(a[["sql"]]), each = length(b[["sql"]]))
  j = rep(seq_along(b[["sql"]]), times = length(a[["sql"]]))
  list(
    sql = paste0("(", a[["sql"]][i], ") * (", b[["sql"]][j], ")"),
    name = paste0(a[["name"]][i], sep, b[["name"]][j]),
    alias = paste0(a[["alias"]][i], "_x_", b[["alias"]][j])
  )
}
